##
#  Programma che illustra il comportamento della funzione print.
#

# Visualizza 7
print(3 + 4) 
      
# Visualizza "Hello World!" su due righe.
print("Hello") 
print("World!")

# Visualizza più valori usando una singola invocazione di print.
print("My favorite numbers are", 3 + 4, "and", 3 + 10) 

# Visualizza tre righe di testo, la seconda delle quali vuota.
print("Goodbye")   
print()
print("Hope to see you again")


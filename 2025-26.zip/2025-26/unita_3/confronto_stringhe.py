stringa1 = "albero"
stringa2 = "Zio"

if stringa1.lower() < stringa2.lower():
    print(f"{stringa1} precede in ordine alfabetico {stringa2}")
else:
    print(f"{stringa2} precede in ordine alfabetico {stringa1}")

# Costanti
CAPACITA_BOTTIGLIA = 0.75
CAPACITA_LATTINA = 0.33

# Dati in input
num_bottiglie = 4
num_lattine = 6

# Calcoli
totale = 0
totale = num_bottiglie * CAPACITA_BOTTIGLIA
totale = totale + num_lattine * CAPACITA_LATTINA

print(totale)

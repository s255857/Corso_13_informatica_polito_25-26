from funzione import volumeParallelepipedo

risultato = volumeParallelepipedo(10, 30, 5)
print(f"Il volume del parallelepipedo è {risultato}")